document.getElementById('loginBtn').addEventListener('click', () => {
  const email = document.getElementById('email').value;
  const pass = document.getElementById('pass').value;

  if (email === "test@ytgo.su" && pass === "robopass2026") {
    document.getElementById('status').innerText = "Статус: PREMIUM (4K ACTIVE)";
    document.getElementById('status').style.color = "#4CAF50";
    alert("Доступ активирован!");
  } else {
    alert("Неверные данные для теста");
  }
});